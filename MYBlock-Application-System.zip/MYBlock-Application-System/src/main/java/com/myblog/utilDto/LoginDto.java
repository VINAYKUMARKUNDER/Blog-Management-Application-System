package com.myblog.utilDto;

import lombok.Data;

@Data
public class LoginDto {
	
	private String email;
	private String password;

}
