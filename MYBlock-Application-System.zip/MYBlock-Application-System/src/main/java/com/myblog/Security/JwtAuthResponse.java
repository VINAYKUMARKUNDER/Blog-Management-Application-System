//package com.myblog.Security;
//
//import lombok.Data;
//
//@Data
//public class JwtAuthResponse {
//	
//	private String token;
//
//}
