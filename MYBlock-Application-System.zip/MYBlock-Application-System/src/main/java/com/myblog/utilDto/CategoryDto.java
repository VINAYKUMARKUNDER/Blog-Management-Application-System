package com.myblog.utilDto;

import lombok.Data;

@Data
public class CategoryDto {
	
	private Integer categoryId;
	private String categoryTitle;
	private String category;

}
