package com.myblog.utilDto;

import lombok.Data;

@Data
public class RoleDtoAdding {
	private Integer roleId;
	private String name;
}
